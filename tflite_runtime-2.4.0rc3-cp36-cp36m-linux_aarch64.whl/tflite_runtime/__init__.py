__version__ = '2.4.0rc3'
__git_version__ = '0.6.0-98255-g68f236364cd'
